<!DOCTYPE html>
<html>
<head>
<title>CineHub.com | Movies, Tickets, Trailers</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <!-- Footer icon -->
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/login.css">
    <script type="text/javascript" src="js/login.js"></script>


</head>
                                      <!-- Navigation -->
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li><a href="mainpage.html"><span>Home Page</span></a></li>
          <li><a href="information.html"><span>Information</span></a></li>
          <li><a href="about.html"><span>About Us</span></a></li>
          <li><a href="feedback.html"><span>Feedback</span></a></li>
          <li class="active"><a href="index.php"><span>Login</span></a></li>
        </ul>
   </div>
     <div class="logo">
        <h1><a href="mainpage.html"><span>CineHub</span> <small>&nbsp;CineHub.com</small></a></h1>
     </div>






                            <!-- Page content -->

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <div class="clr"></div>
        </div>
<?php
  require "header.php";
?>

    <main>
      <div class="wrapper-main">
        <section class="section-default">
          <?php
          if (!isset($_SESSION['id'])) {
            echo '<p class="login-status">You are logged out!</p>';
          }
          else if (isset($_SESSION['id'])) {
            echo '<p class="login-status">You are logged in!</p>';
          }
          ?>
        </section>
      </div>
    </main>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js" type="text/javascript"></script>




      <div class="article">
          <br>
          <div class="clr"></div>

        </div>
      </div>




                            <!-- Sidebar -->
      <div class="sidebar">
        <div class="searchform"></div>
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="mainpage.html">Home</a></li>
            <li><a href="Information.html">Information</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="feedback.html">Feedback</a></li>
            <li class="active" ><a href="login.html">Login</a></li>
          </ul>
        </div>
      </div>

      <div class="clr"></div>
    </div>
  </div>






                            <!-- Footer -->
	  <footer class="footer-distributed">
			  <div class="footer-left">
				    <h3>Cine<span>Hub</span></h3>
				    <p class="footer-links">
                  <a href="#">Wael Aiden Waadallah - n01095260</a>
                  ·
                  <a href="#">Dario Qinami - n12345678</a>
                  ·
                  <a href="#">Lee - n12345678</a>
                  ·
                  <a href="#">Elias Sabbagh - n01114446</a>
            </p>
            <p class="footer-company-name">CineHub &copy; 2019</p>
		  	</div>
		  	<div class="footer-center">
				<div>
                  <i class="fa fa-map-marker"></i>
                  <p><span>259 Richmond St W</span> Toronto, ON</p>
				</div>
				<div>
                  <i class="fa fa-phone"></i>
                  <p>(123) 456-7890</p>
				</div>
				<div>
                  <i class="fa fa-envelope"></i>
                  <p><a href="mailto:support@company.com">cinehub@gmail.com</a></p>
				</div>
		  	</div>
	  		<div class="footer-right">
                  <p class="footer-company-about">
                    <span>About the company</span>
                    CineHub is a Canadian entertainment company headquartered in Toronto, Ontario.
                  </p>

			</div>
		</footer>
  </body>
</html>
