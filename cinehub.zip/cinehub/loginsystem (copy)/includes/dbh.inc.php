<?php

     $db_host="localhost";
     $db_username="cinehub";
     $db_passwd="password";

$conn=mysqli_connect('localhost','cinehub','password','addressbook')
	 or die ("Could not Connect! \n");
?>
