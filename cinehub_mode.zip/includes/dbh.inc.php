<?php

     $db_host="localhost";
     $db_username="cinehub";
     $db_passwd="password";

$conn=mysqli_connect($db_host,$db_username,$db_passwd,'users')
	 or die ("Could not Connect! \n");

?>
